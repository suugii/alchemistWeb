@extends('layouts.app')

@section('title', '403')

@section('masthead')
<h1 class="ui inverted centered center aligned header">403</h1>
@endsection