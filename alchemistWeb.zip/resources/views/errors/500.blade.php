@extends('layouts.app')

@section('title', '500')

@section('masthead')
<h1 class="ui inverted centered center aligned header">500</h1>
@endsection