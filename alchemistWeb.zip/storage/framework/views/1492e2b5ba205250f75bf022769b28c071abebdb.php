<div class="ui inverted masthead centered segment">
	<div class="ui page grid">
		<div class="column">
			<div class="ui secondary pointing menu">
				<a class="toc item">
					<i class="sidebar icon"></i>
				</a>
				 <a class="logo item">
					Alchemist
				</a>
				<a class="item active">
					CRM
				</a>
				<a class="item">
					PMS
				</a>
				<a class="item">
					Spend Control & eProcurement
				</a>
				<a class="item">
					Other projects
				</a>
				<a class="item">
					 Nomadic Bear Games
				</a>
				<div class="right menu">
					<a class="ui item">
						Mонгол хэл
					</a>
					<a class="ui item" style="color:white">
						LOGIN 
					</a> 
				</div>
			</div>
			<div class="ui hidden transition information">
				<?php echo $__env->yieldContent('mcontent'); ?>
			</div>
		</div>
	</div>
</div>