<?php $__env->startSection('title', 'Alchemist Turns into Gold'); ?>

<?php $__env->startSection('masthead'); ?>
	<h1 class="ui inverted centered center aligned header">Customer relationship management 
		<small style="font-size: 12px">powered by 
			<a href="#">Alchemist Platfrom & vTiger Frontend</a>
		</small>
	</h1><br/>
	<span class="ui centered lead" style="font-size: 18px">Customized for mid-sized <strong>retail</strong> companies<br/> to document, controll and manage their sales, purchases and warehouses</span>
	<div class="ui grid stackable centered center aligned">
		<div class="three wide column"></div>
		<div class="three wide column"> 
			<a href="#" class="large basic inverted animated fade ui button">
				<div class="visible content">REQUEST A DEMO</div>
				<div class="hidden content">Make appoinment?</div>
			</a>
		</div>
		<div class="three wide column"></div>
	</div>
	<div class="ui centerted image device only">
		<p><img src="<?php echo e(asset('img/banner2.png')); ?>"/></p>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>