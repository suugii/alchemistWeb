<div class="ui top fixed hidden menu" >
	<div class="ui container">
		<div class="item">
			<img class="ui small  image" src="<?php echo e(asset('img/logo.png')); ?>">
		</div>
		<a class="active item" href="<?php echo e(url('/')); ?>"><?php echo e(trans('messages.crm')); ?></a>
		<a class="item" href="<?php echo e(url('pms')); ?>" style="color: rgba(81, 79, 79, 0.73);" >PMS</a>
		<a class="item" href="<?php echo e(url('eprocurement')); ?>" style="color: rgba(81, 79, 79, 0.73);"><?php echo e(trans('messages.spend control & eprocurement')); ?></a>
		<a class="item" href="<?php echo e(url('projects')); ?>" style="color: rgba(81, 79, 79, 0.73);"><?php echo e(trans('messages.other projects')); ?></a>
		<a class="item" style="color: rgba(81, 79, 79, 0.73);"><?php echo e(trans('messages.nomadic bear games')); ?></a>
		<div class="right menu">
			<div class="item">
				<a href="#">+976-88021087</a>
			</div>
			<div class="item">
				<a href="#">info@alchemist.mn</a>
			</div>
			<div class="item">
				<a class="ui button"><?php echo e(trans('messages.login')); ?></a>
			</div>
		</div>
	</div>
</div>
<div class="ui vertical inverted sidebar menu">
	<a class="active item" href="<?php echo e(url('/')); ?>"><?php echo e(trans('crm')); ?></a>
	<a class="item" href="<?php echo e(url('pms')); ?>"><?php echo e(trans('pms')); ?></a>
	<a class="item" href="<?php echo e(url('eprocurement')); ?>"><?php echo e(trans('messages.spend control & eprocurement')); ?></a>
	<a class="item"><?php echo e(trans('messages.messages.nomadic bear games')); ?></a>
	<a class="item" href="<?php echo e(url('projects')); ?>"><?php echo e(trans('messages.other projects')); ?></a>
	<a class="item"><?php echo e(trans('messages.login')); ?></a>
</div>
